import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-recieve-bubble',
  templateUrl: './recieve-bubble.component.html',
  styleUrls: ['./recieve-bubble.component.scss']
})
export class RecieveBubbleComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
