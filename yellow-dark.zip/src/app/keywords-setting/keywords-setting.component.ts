import { Component, OnInit } from '@angular/core';
import { KeyWord } from '../../assets/scripts/KeyWord';
import { DbService, YellowDB } from '../db.service';

interface FixedIDBVersionChangeEvent extends IDBVersionChangeEvent {
  target: IDBOpenDBRequest
}

@Component({
  selector: 'app-keywords-setting',
  templateUrl: './keywords-setting.component.html',
  styleUrls: ['./keywords-setting.component.scss']
})
export class KeywordsSettingComponent implements OnInit {
  private dataBase: YellowDB;
  public allData: KeyWord[] = [];
  constructor(
    public dbService: DbService
  ) {
    // this.initDB().then(async () => {
    //   // this.allData = await this.getAll();
    // });
    dbService.getDB.then(async (db) => {
      this.dataBase = db;
      this.allData = await this.getAll();
    });
  }
  initDB() {
    // const request = window.indexedDB.open('yellow-duck', 1);
    // request.onupgradeneeded = (e: FixedIDBVersionChangeEvent) => {
    //   if (!e.target.result.objectStoreNames.contains('keywords')) {
    //     const objectStore = e.target.result.createObjectStore('keywords', {
    //       keyPath: 'word',
    //     });
    //     objectStore.createIndex('level', 'level');
    //     objectStore.createIndex('category', 'category');
    //   }
    // }
    // return new Promise(resolve => {
    //   request.onsuccess = () => {
    //     resolve(this.db = request.result);
    //   }
    // });
  }
  addRecord() {
    // const request = this.db.transaction('keywords', 'readwrite')
    // .objectStore('keywords')
    // .add({word: 'test1', level: 1, category: 'test'});
    // request.onsuccess = () => {
    //   alert('success');
    // };
  }
  delete() {
    // const request = this.db.transaction('keywords', 'readwrite')
    // .objectStore('keywords')
    // .delete('test1');
    // request.onsuccess = () => {
    //   alert('success');
    // };
  }
  find() {
    // const request = this.db.transaction('keywords', 'readonly')
    // .objectStore('keywords')
    // .get('test1');
    // request.onsuccess = (e) => {
    //   console.log(request.result);
    // }
  }
  async getAll() {
    // const request = this.db.transaction('KeyWord', 'readonly')
    // .objectStore('KeyWord')
    // .getAll();
    // return new Promise<KeyWord[]>(resolve =>
    //   request.onsuccess = () => {
    //     resolve(request.result);
    //   }
    // )
    return await this.dataBase.getRepository('KeyWord').getAll();
  }
  ngOnInit() {
  }
}
