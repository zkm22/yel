import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sent-bubble',
  templateUrl: './sent-bubble.component.html',
  styleUrls: ['./sent-bubble.component.scss']
})
export class SentBubbleComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
